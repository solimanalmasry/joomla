Before u run the bot
u have to remove "http://" or "https://" from the websites list 

and don't forget to subscribe in my channel 